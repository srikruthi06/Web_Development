const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');

// Path to bookings.json
const dataDir = path.join(__dirname, 'data');
const bookingsFilePath = path.join(dataDir, 'bookings.json');

// Helper function to read bookings
const readBookings = () => {
  try {
    if (!fs.existsSync(bookingsFilePath)) {
      return [];
    }
    const data = fs.readFileSync(bookingsFilePath, 'utf8');
    return JSON.parse(data);
  } catch (error) {
    console.error('Error reading bookings:', error);
    return [];
  }
};

// Helper function to write bookings
const writeBookings = (bookings) => {
  try {
    // Create data directory if it doesn't exist
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    fs.writeFileSync(bookingsFilePath, JSON.stringify(bookings, null, 2));
  } catch (error) {
    console.error('Error writing bookings:', error);
  }
};

// GET all bookings
router.get('/', (req, res) => {
  try {
    const bookings = readBookings();
    res.json(bookings);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// POST a new booking with detailed logging
router.post('/', (req, res) => {
  try {
    console.log('\n=================================');
    console.log('POST request received at /api/bookings');
    console.log('Request body:', JSON.stringify(req.body, null, 2));
    console.log('=================================\n');
    
    const bookings = readBookings();
    console.log(`Current bookings count: ${bookings.length}`);
    
    const newBooking = {
      id: Date.now(),
      ...req.body,
      createdAt: new Date().toISOString()
    };
    
    bookings.push(newBooking);
    writeBookings(bookings);
    
    console.log(`Booking saved! New total: ${bookings.length}`);
    console.log(`Booking reference: ${newBooking.reference}\n`);
    
    res.status(201).json(newBooking);
  } catch (error) {
    console.error('Error saving booking:', error);
    res.status(400).json({ message: error.message });
  }
});

// DELETE all bookings
router.delete('/', (req, res) => {
  try {
    writeBookings([]);
    res.json({ message: 'All bookings cleared' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// DELETE a single booking
router.delete('/:id', (req, res) => {
  try {
    const bookings = readBookings();
    const filteredBookings = bookings.filter(b => b.id !== parseInt(req.params.id));
    writeBookings(filteredBookings);
    res.json({ message: 'Booking deleted' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;